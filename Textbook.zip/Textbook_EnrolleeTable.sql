USE [Textbook]
GO

/****** Object:  Table [dbo].[Enrollee]    Script Date: 12/31/2017 12:15:24 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Enrollee](
	[EnrolleeID] [int] NOT NULL,
	[Username] [varchar](max) NULL,
	[Password] [varchar](max) NULL,
	[FirstName] [varchar](max) NULL,
	[LastName] [varchar](max) NULL,
 CONSTRAINT [PK_Enrollee] PRIMARY KEY CLUSTERED 
(
	[EnrolleeID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

