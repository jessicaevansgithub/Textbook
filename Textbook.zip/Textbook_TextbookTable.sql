USE [Textbook]
GO

/****** Object:  Table [dbo].[Textbook]    Script Date: 12/31/2017 12:17:56 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Textbook](
	[ISBN] [int] NOT NULL,
	[AuthorID] [int] NULL,
	[PublisherID] [int] NULL,
	[Title] [varchar](max) NULL,
	[AuthorFirstName] [varchar](max) NULL,
	[AuthorLastName] [varchar](max) NULL,
	[EditionNumber] [int] NULL,
	[YearPublished] [int] NULL,
 CONSTRAINT [PK_Textbook] PRIMARY KEY CLUSTERED 
(
	[ISBN] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

ALTER TABLE [dbo].[Textbook]  WITH CHECK ADD FOREIGN KEY([AuthorID])
REFERENCES [dbo].[Author] ([AuthorID])
GO

ALTER TABLE [dbo].[Textbook]  WITH CHECK ADD FOREIGN KEY([PublisherID])
REFERENCES [dbo].[Publisher] ([PublisherID])
GO

