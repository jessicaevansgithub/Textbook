USE [Textbook]
GO

/****** Object:  Table [dbo].[Order_]    Script Date: 12/31/2017 12:16:03 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Order_](
	[OrderID] [int] NOT NULL,
	[EnrolleeID] [int] NULL,
	[ISBN] [int] NULL,
	[Cost] [money] NULL,
	[DateOfPurchase] [date] NULL,
 CONSTRAINT [PK_Order_] PRIMARY KEY CLUSTERED 
(
	[OrderID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[Order_]  WITH CHECK ADD FOREIGN KEY([EnrolleeID])
REFERENCES [dbo].[Enrollee] ([EnrolleeID])
GO

ALTER TABLE [dbo].[Order_]  WITH CHECK ADD FOREIGN KEY([ISBN])
REFERENCES [dbo].[Textbook] ([ISBN])
GO

